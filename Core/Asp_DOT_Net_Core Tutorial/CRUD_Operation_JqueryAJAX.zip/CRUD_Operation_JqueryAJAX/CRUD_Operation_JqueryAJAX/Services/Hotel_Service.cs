﻿using CRUD_Operation_JqueryAJAX.Models;
using CRUD_Operation_JqueryAJAX.Repository;

namespace CRUD_Operation_JqueryAJAX.Services
{
    public class Hotel_Service : IHotel_Service
    {
        private readonly IHotel_Repository _repository;
        public Hotel_Service(IHotel_Repository repository)
        {
            _repository = repository;
        }

        public async Task<List<HotelModel>> getHotelDataList()
        {
            return await _repository.getHotelDataList();
            throw new Exception("Failed to get Hotel List");
        }

        public async Task<int> AddOrderItems(HotelModel modelObj)
        {
            return await _repository.AddOrderItems(modelObj);
            throw new Exception("Failed to add Customer order list");
        }

        public async Task<HotelModel> getOrderDetailsByCustId(int custId)
        {
            return await _repository.getOrderDetailsByCustId(custId);
            throw new Exception("Failed to get customer order data");
        }

        public async Task<int> UpdateOrderItems(HotelModel modelObj)
        {
            return await _repository.UpdateOrderItems(modelObj);
            throw new Exception("Failed to update customer order data");
        }

        public async Task<HotelModel> ViewOrderDetailsById(int custId)
        {
            return await _repository.ViewOrderDetailsById(custId);
            throw new Exception("Failed to view customer order details");
        }

        public async Task<int> DeleteOrderItem(int custId)
        {
            return await _repository.DeleteOrderItem(custId);
            throw new Exception("Failed to delete customer order data");
        }
    }
}
