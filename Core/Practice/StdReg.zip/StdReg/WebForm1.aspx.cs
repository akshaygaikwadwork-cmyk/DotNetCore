﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StdReg
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string con = ConfigurationManager.ConnectionStrings["dbcs"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                ShowData();
                genderData();
                if (Request.QueryString.Count > 0)
                {
                    if (Request.QueryString["Id"].ToString() != "")
                    {
                        string id = Request.QueryString["Id"].ToString();
                        fillDataEdit(id);
                    }
                }
            }
        }

        //protected void btnSub_Click(object sender, EventArgs e)
        //{
        //    if(hiddenfield.Value == "")
        //    {
        //        InsertData();
        //        ShowData();
        //    }
        //    else
        //    {
        //        UpdateData();
        //        ShowData();
        //    }
        //}

        public void InsertData()
        {
            SqlConnection cn = new SqlConnection(con);
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("mystd", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Insert");

                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@MotherName", txtMotherName.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@EmailId", txtEmailId.Text);
                cmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNO.Text);
                cmd.Parameters.AddWithValue("@Dob", txtDob.Text);
                cmd.Parameters.AddWithValue("@Category", txtCat.Text);
                cmd.Parameters.AddWithValue("@Gender", ddlGen.SelectedItem.Text);



                int data = cmd.ExecuteNonQuery();
                if (data > 0)
                {
                    lblData.Text = "Data Inserted Sucessfully";
                }
                else
                {
                    lblData.Text = "Data Insertion Failed";
                }
            }
            catch (Exception e)
            {
                lblData.Text = e.Message;
            }
            finally
            {
                cn.Close();
            }
            txtname.Text = null;
            txtFatherName.Text = null;
            txtMotherName.Text = null;
            txtAddress.Text = null;
            txtEmailId.Text = null;
            txtPhoneNO.Text = null;
            txtDob.Text = null;
            txtCat.Text = null;
            ddlGen.SelectedItem.Text = null;
        }

        public void genderData()
        {
            SqlConnection cn = new SqlConnection(con);
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("mystd", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Gender");
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                {
                    ddlGen.DataSource = dt;
                    ddlGen.DataTextField = "genName";
                    ddlGen.DataBind();
                }



            }
            catch (Exception e)
            {
                Response.Write(e.Message);
            }
            finally
            {
                cn.Close();
            }
        }


        public void UpdateData()
        {
            SqlConnection cn = new SqlConnection(con);
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("mystd", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Update");
                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@MotherName", txtMotherName.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@EmailId", txtEmailId.Text);
                cmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNO.Text);
                cmd.Parameters.AddWithValue("@Dob", txtDob.Text);
                cmd.Parameters.AddWithValue("@Category", txtCat.Text);
                cmd.Parameters.AddWithValue("@Gender", ddlGen.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Id", hiddenfield.Value);

                int data = cmd.ExecuteNonQuery();
                if (data > 0)
                {
                    lblData.Text = "Data Updated Sucessfully";
                }
                else
                {
                    lblData.Text = "Data Updation Failed";
                }
            }
            catch (Exception e)
            {
                lblData.Text = e.Message;
            }
            finally
            {
                cn.Close();
            }
            txtname.Text = null;
            txtFatherName.Text = null;
            txtMotherName.Text = null;
            txtAddress.Text = null;
            txtEmailId.Text = null;
            txtPhoneNO.Text = null;
            txtDob.Text = null;
            txtCat.Text = null;
            ddlGen.SelectedItem.Text = null;
        }


        public void DeleteData(string id)
        {
            SqlConnection cn = new SqlConnection(con);
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("mystd", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Delete");
                cmd.Parameters.AddWithValue("@Id", id);

                int data = cmd.ExecuteNonQuery();
                if (data > 0)
                {
                    ShowData();
                }
                else
                {
                    ShowData();
                }
            }
            catch (Exception e)
            {
                lblData.Text = e.Message;
            }
            finally
            {
                cn.Close();
            }
        }

        public void ShowData()
        {
            SqlConnection cn = new SqlConnection(con);
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("mystd", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Select");
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    gridview1.DataSource = dt;
                    gridview1.DataBind();
                }
                else
                {
                    gridview1.DataSource = dt;
                    gridview1.DataBind();

                }
            }
            catch (Exception e)
            {
                lblData.Text = e.Message;
            }
            finally
            {
                cn.Close();
            }
        }

        public void fillDataEdit(string id)
        {
            SqlConnection cn = new SqlConnection(con);
            try
            {
                SqlCommand cmd = new SqlCommand("mystd", cn);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Type");
                cmd.Parameters.AddWithValue("@Id", id);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    hiddenfield.Value = ds.Tables[0].Rows[0]["Id"].ToString();
                    txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    txtFatherName.Text = ds.Tables[0].Rows[0]["FatherName"].ToString();
                    txtMotherName.Text = ds.Tables[0].Rows[0]["MotherName"].ToString();
                    txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                    txtEmailId.Text = ds.Tables[0].Rows[0]["EmailId"].ToString();
                    txtPhoneNO.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
                    txtDob.Text = ds.Tables[0].Rows[0]["Dob"].ToString();
                    txtCat.Text = ds.Tables[0].Rows[0]["Category"].ToString();
                    if (ds.Tables[0].Rows[0]["Gender"].ToString() != "")
                    {
                        ddlGen.SelectedValue = ds.Tables[0].Rows[0]["Gender"].ToString();
                    }
                }
            }
            catch (Exception e)
            {
                lblData.Text = e.Message;
            }
            finally
            {
                cn.Close();
            }



        }

        protected void gridview1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            string id = ((Label)(gridview1.Rows[e.NewEditIndex].Cells[0].FindControl("lblId"))).Text;
            fillDataEdit(id);

        }

        protected void gridview1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string id = ((Label)(gridview1.Rows[e.RowIndex].Cells[0].FindControl("lblId"))).Text;
            DeleteData(id);
        }

        protected void btnSub_Click1(object sender, EventArgs e)
        {
            if (hiddenfield.Value == "")
            {
                InsertData();
                ShowData();
            }
            else
            {
                UpdateData();
                ShowData();
            }
        }

        protected void btnRes_Click(object sender, EventArgs e)
        {
            txtname.Text = null;
            txtFatherName.Text = null;
            txtMotherName.Text = null;
            txtAddress.Text = null;
            txtEmailId.Text = null;
            txtPhoneNO.Text = null;
            txtDob.Text = null;
            txtCat.Text = null;
            ddlGen.SelectedItem.Text = null;
        }
    }
}