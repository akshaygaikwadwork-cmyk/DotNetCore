﻿using DependecyWithServiceCollection.Classes;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();
app.MapGet("/", () => "Hello World!");

var collection = new ServiceCollection();

// Register services
collection.AddSingleton<ClassA>();
collection.AddScoped<ClassA>();
collection.AddTransient<ClassA>();

var provider = collection.BuildServiceProvider();

// Singleton Test
Console.WriteLine("--------- Singleton Object Creation ---------");
for (int i = 0; i < 5; i++)
{
    var obj = provider.GetService<ClassA>();
    Console.WriteLine($"Singleton object {i}: {obj.Id}");
}

Console.WriteLine("--------- Scoped Object Creation ---------");
for (int i = 0; i < 2; i++)
{
    using (var scope = provider.CreateScope())
    {
        var scopedProvider = scope.ServiceProvider;
        for (int j = 0; j < 3; j++)
        {
            var obj = scopedProvider.GetService<ClassA>();
            Console.WriteLine($"Scoped object {i}.{j}: {obj.Id}");
        }
    }
}

Console.WriteLine("--------- Transient Object Creation ---------");
for (int i = 0; i < 5; i++)
{
    var obj = provider.GetService<ClassA>();
    Console.WriteLine($"Transient object {i}: {obj.Id}");
}
app.Run();
