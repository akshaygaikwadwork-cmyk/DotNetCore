﻿namespace DependecyWithServiceCollection.Classes
{
    public class ClassA
    {
        public Guid Id { get; } = Guid.NewGuid();
    }
}
