﻿using StudnetMVCCRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StudnetMVCCRUD.Controllers
{
    public class StudentController : Controller
    {

        // GET: Student
        public ActionResult Index()
        {
            StudentData sd = new StudentData();
            ViewBag.objsate = sd.StateDDLData();
            return View();
        }

        [HttpGet]
        public ActionResult ShowData()
        {
            try
            {
                StudentData sd = new StudentData();
                var data = sd.ShowData();
                return View(data);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Response.Write("code ends :");

            }

        }

        [HttpPost]
        public ActionResult Index(Student student)
        {

            try
            {
                StudentData sd = new StudentData();
                if (ModelState.IsValid == true)
                {
                    sd.Insertdata(student);
                    TempData["Msg"] = "data submitted successfully";
                    return RedirectToAction("ShowData");
                }
                else
                {
                    TempData["Msg"] = "Student does not Inserted Successfully";
                    ViewBag.objsate = sd.StateDDLData();
                    return View();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Response.Write("code ends :");

            }
        }

        public ActionResult editData(int id)
        {
            try
            {
                StudentData sd = new StudentData();
                Student student = new Student();
                student.Id = id;
                bool a = sd.editData(student);
                if (a == true)
                {
                    ViewBag.objsate = sd.StateDDLData();
                    return View(student);
                }
                else
                {
                    TempData["Msg"] = "invalid data";
                    return View();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Response.Write("code ends :");
            }

        }

        [HttpPost]
        public ActionResult editData(Student student)
        {
            try
            {
                StudentData sd = new StudentData();
                if (ModelState.IsValid == true)
                {
                    sd.updateData(student);
                    TempData["successMsg"] = "<script>alert('data submitted successfully :)</script>";
                    return RedirectToAction("ShowData");
                }
                else
                {
                    TempData["InsertErrorMsg"] = "<script>alert('Student does not Inserted Successfully')</script>";

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Response.Write("code ends :");
            }



            return View();
        }

        public ActionResult deleteData(int id)
        {
            Student student = new Student();
            student.Id = id;
            StudentData sd = new StudentData();
            bool d = sd.deleteData(student);
            if (d == true)
            {

                return RedirectToAction("ShowData");
            }
            else
            {
                TempData["Msg"] = "invalid data";
                return View();
            }


        }

    }
}