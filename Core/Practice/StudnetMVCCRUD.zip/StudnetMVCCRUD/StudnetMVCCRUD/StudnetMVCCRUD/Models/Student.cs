﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace StudnetMVCCRUD.Models
{
    public class Student
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Name is Mandotory")]
        [DisplayName("Name")]
        [StringLength(100)]

        public string Name { get; set; }

        [Required(ErrorMessage = "Age is mandotory")]
        [DisplayName("StdAge")]
        [Range(0, 100)]

        public int Age { get; set; }


        [Required(ErrorMessage = "Email is Mandotory")]
        [DisplayName("EmailId")]
        [StringLength(100)]
        public string Email { get; set; }


        [Required(ErrorMessage = "Address is Mandotory")]
        [DisplayName("Address")]
        [StringLength(100)]
        public string address { get; set; }

        [Required(ErrorMessage = "Feedabck is Mandotory")]
        [DisplayName("Feedback")]
        [StringLength(300, MinimumLength = 2, ErrorMessage = "Address Length Between 2 and 50")]
        [DataType(DataType.MultilineText)]
        public string feedback { get; set; }

        [Required(ErrorMessage = "State is Mandotory")]
        [DisplayName("States")]
        public string state { get; set; }

        [Required(ErrorMessage = "Gender is Mandotory")]
        [DisplayName("Gender")]

        public string gender { get; set; }



    }

    public class StudentData
    {
        string conn = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;


        public bool Insertdata(Student stdmodel)
        {
            SqlConnection cn = new SqlConnection(conn);
            try
            {

                cn.Open();
                SqlCommand cmd = new SqlCommand("MYSTD", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Insert");
                cmd.Parameters.AddWithValue("@StdName", stdmodel.Name);
                cmd.Parameters.AddWithValue("@StdAge", stdmodel.Age);
                cmd.Parameters.AddWithValue("@StdEmail", stdmodel.Email);
                cmd.Parameters.AddWithValue("@StdAddress", stdmodel.address);
                cmd.Parameters.AddWithValue("@StdFeedback", stdmodel.feedback);
                cmd.Parameters.AddWithValue("@StdState", stdmodel.state);

                cmd.Parameters.AddWithValue("@StdGender", stdmodel.gender);
                cmd.Parameters.AddWithValue("@created_by", "saurabh");
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
        }

        public List<Student> StateDDLData()
        {
            List<Student> list = new List<Student>();

            SqlConnection cn = new SqlConnection(conn);
            try
            {
                SqlCommand cmd = new SqlCommand("MYSTD", cn);
                cn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "States");
                cmd.ExecuteNonQuery();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Student Statelist = new Student();
                    Statelist.Id = Convert.ToInt32(dt.Rows[i]["StateId"]);
                    Statelist.state = dt.Rows[i]["Statename"].ToString();
                    list.Add(Statelist);

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();

            }
            return list;


        }


        //public List<Student> genderDDLDATA()
        //{
        //    List<Student> list = new List<Student>();

        //    SqlConnection cn = new SqlConnection(conn);
        //    try
        //    {
        //        SqlCommand cmd = new SqlCommand("MYSTD", cn);
        //        cn.Open();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@Action", "Gender");
        //        cmd.ExecuteNonQuery();
        //        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        //        DataTable dt = new DataTable();
        //        sda.Fill(dt);
        //        for(int i = 0; i < dt.Rows.Count;i++)
        //        {
        //            Student Genderlist = new Student();
        //            Genderlist.gender = dt.Rows[i]["GenderName"].ToString();
        //            list.Add(Genderlist);
        //        }


        //    }
        //    catch(Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        cn.Close();
        //    }
        //}

        public List<Student> ShowData()
        {
            List<Student> list = new List<Student>();
            SqlConnection cn = new SqlConnection(conn);
            try
            {
                SqlCommand cmd = new SqlCommand("MYSTD", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                cmd.Parameters.AddWithValue("@Action", "Select");
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    Student studentlist = new Student();
                    studentlist.Id = Convert.ToInt32(dt.Rows[i]["StdID"]);
                    studentlist.Name = dt.Rows[i]["StdName"].ToString();
                    studentlist.Age = Convert.ToInt32(dt.Rows[i]["StdAge"]);
                    studentlist.Email = dt.Rows[i]["StdEmail"].ToString();
                    studentlist.address = dt.Rows[i]["StdAddress"].ToString();
                    studentlist.feedback = dt.Rows[i]["StdFeedback"].ToString();
                    studentlist.state = dt.Rows[i]["StdState"].ToString();
                    studentlist.gender = dt.Rows[i]["StdGender"].ToString();
                    list.Add(studentlist);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return list;
        }


        //To post
        public bool updateData(Student student)
        {
            SqlConnection cn = new SqlConnection(conn);
            try
            {
                SqlCommand cmd = new SqlCommand("MYSTD", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Update");
                cmd.Parameters.AddWithValue("@StdName", student.Name);
                cmd.Parameters.AddWithValue("@StdAge", student.Age);
                cmd.Parameters.AddWithValue("@StdEmail", student.Email);
                cmd.Parameters.AddWithValue("@StdAddress", student.address);
                cmd.Parameters.AddWithValue("@StdFeedback", student.feedback);
                cmd.Parameters.AddWithValue("@StdState", student.state);
                cmd.Parameters.AddWithValue("@StdGender", student.gender);
                cmd.Parameters.AddWithValue("@StdID", student.Id);
                cn.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
        }

        //To get
        public bool editData(Student student)
        {
            SqlConnection cn = new SqlConnection(conn);
            try
            {

                SqlCommand cmd = new SqlCommand("MYSTD", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Edit");
                cmd.Parameters.AddWithValue("@StdID", student.Id);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                cn.Open();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    student.Id = Convert.ToInt32(ds.Tables[0].Rows[0]["StdID"]);
                    student.Name = ds.Tables[0].Rows[0]["StdName"].ToString();
                    student.Age = Convert.ToInt32(ds.Tables[0].Rows[0]["StdAge"]);
                    student.Email = ds.Tables[0].Rows[0]["StdEmail"].ToString();
                    student.address = ds.Tables[0].Rows[0]["StdAddress"].ToString();
                    student.feedback = ds.Tables[0].Rows[0]["StdFeedback"].ToString();
                    student.state = ds.Tables[0].Rows[0]["StdState"].ToString();
                    student.gender = ds.Tables[0].Rows[0]["StdGender"].ToString();

                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
        }

        public bool deleteData(Student student)
        {
            SqlConnection cn = new SqlConnection(conn);
            try
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("MYSTD", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "Delete");
                cmd.Parameters.AddWithValue("@StdID", student.Id);
                int data = cmd.ExecuteNonQuery();
                if (data > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }

        }
    }


}